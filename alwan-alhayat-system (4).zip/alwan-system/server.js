/**
 * ألوان الحياة للديكور — الخادم الخلفي (Backend)
 * خادم Node.js بدون أي مكتبات خارجية — يعمل مباشرة بأمر: node server.js
 * يخزّن البيانات في ملف data/database.json (قاعدة بيانات محلية بصيغة JSON)
 * وياخذ نسخة احتياطية تلقائية قبل كل عملية حفظ داخل data/backups/
 */
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const PORT = process.env.PORT || 3000;
const ROOT = __dirname;
const DATA_DIR = path.join(ROOT, 'data');
const BACKUP_DIR = path.join(DATA_DIR, 'backups');
const DB_FILE = path.join(DATA_DIR, 'database.json');
const CONFIG_FILE = path.join(DATA_DIR, 'config.json');
const PUBLIC_DIR = path.join(ROOT, 'public');
const MAX_BACKUPS = 30;
const DEFAULT_PASSWORD = 'alwan2026';
const SESSION_TTL_MS = 7 * 24 * 60 * 60 * 1000; // أسبوع

/* ---------------- إعداد كلمة المرور (مرة واحدة عند أول تشغيل) ---------------- */
function hashPassword(password, salt) {
  return crypto.scryptSync(password, salt, 64).toString('hex');
}
function ensureConfig() {
  if (!fs.existsSync(CONFIG_FILE)) {
    const salt = crypto.randomBytes(16).toString('hex');
    const hash = hashPassword(DEFAULT_PASSWORD, salt);
    fs.writeFileSync(CONFIG_FILE, JSON.stringify({ salt, hash }, null, 2), 'utf8');
    console.log('تم إنشاء كلمة مرور افتراضية: ' + DEFAULT_PASSWORD + ' — غيّرها من تبويب "الإعدادات" داخل النظام.');
  }
}
function readConfig() { return JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8')); }
function writeConfig(cfg) { fs.writeFileSync(CONFIG_FILE, JSON.stringify(cfg, null, 2), 'utf8'); }
function verifyPassword(password) {
  const cfg = readConfig();
  return hashPassword(password, cfg.salt) === cfg.hash;
}

/* ---------------- الجلسات (Sessions) ---------------- */
const SESSIONS = new Map(); // token -> expiry timestamp
function createSession() {
  const token = crypto.randomBytes(24).toString('hex');
  SESSIONS.set(token, Date.now() + SESSION_TTL_MS);
  return token;
}
function isValidSession(token) {
  if (!token || !SESSIONS.has(token)) return false;
  if (Date.now() > SESSIONS.get(token)) { SESSIONS.delete(token); return false; }
  return true;
}
function getCookie(req, name) {
  const raw = req.headers.cookie || '';
  const match = raw.split(';').map(s => s.trim()).find(s => s.startsWith(name + '='));
  return match ? decodeURIComponent(match.split('=')[1]) : null;
}

function ensureDb() {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
  if (!fs.existsSync(BACKUP_DIR)) fs.mkdirSync(BACKUP_DIR, { recursive: true });
  if (!fs.existsSync(DB_FILE)) {
    const initial = { clients: [], inventory: {}, purchases: [], expenses: [] };
    fs.writeFileSync(DB_FILE, JSON.stringify(initial, null, 2), 'utf8');
    console.log('تم إنشاء قاعدة بيانات جديدة في: ' + DB_FILE);
  }
}
ensureDb();
ensureConfig();

function readDb() {
  try {
    const raw = fs.readFileSync(DB_FILE, 'utf8');
    const data = JSON.parse(raw);
    if (!data.clients) data.clients = [];
    if (!data.inventory) data.inventory = {};
    if (!data.purchases) data.purchases = [];
    if (!data.expenses) data.expenses = [];
    return data;
  } catch (e) {
    return { clients: [], inventory: {}, purchases: [], expenses: [] };
  }
}

function backupDb() {
  try {
    const stamp = new Date().toISOString().replace(/[:.]/g, '-');
    const file = path.join(BACKUP_DIR, `backup-${stamp}.json`);
    fs.copyFileSync(DB_FILE, file);
    const files = fs.readdirSync(BACKUP_DIR).filter(f => f.startsWith('backup-')).sort();
    while (files.length > MAX_BACKUPS) {
      fs.unlinkSync(path.join(BACKUP_DIR, files.shift()));
    }
  } catch (e) {
    console.error('تعذّر أخذ نسخة احتياطية:', e.message);
  }
}

// طابور كتابة بسيط لمنع تعارض الحفظ المتزامن
let writeQueue = Promise.resolve();
function writeDb(data) {
  writeQueue = writeQueue.then(() => {
    backupDb();
    return new Promise((resolve, reject) => {
      fs.writeFile(DB_FILE, JSON.stringify(data, null, 2), 'utf8', (err) => {
        if (err) reject(err); else resolve();
      });
    });
  });
  return writeQueue;
}

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.webp': 'image/webp',
  '.png': 'image/png',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon'
};

function sendJson(res, status, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Content-Length': Buffer.byteLength(body) });
  res.end(body);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on('data', (c) => {
      size += c.length;
      if (size > 20 * 1024 * 1024) { reject(new Error('الطلب كبير جدًا')); req.destroy(); return; }
      chunks.push(c);
    });
    req.on('end', () => {
      if (chunks.length === 0) return resolve(null);
      try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8'))); }
      catch (e) { reject(new Error('صيغة JSON غير صالحة')); }
    });
    req.on('error', reject);
  });
}

function serveStatic(req, res, urlPath) {
  const safePath = path.normalize(urlPath).replace(/^(\.\.[/\\])+/, '');
  let filePath = path.join(PUBLIC_DIR, safePath === '/' || safePath === '' ? 'index.html' : safePath);
  if (!filePath.startsWith(PUBLIC_DIR)) { res.writeHead(403); res.end('Forbidden'); return; }
  fs.readFile(filePath, (err, content) => {
    if (err) {
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('الصفحة غير موجودة');
      return;
    }
    const ext = path.extname(filePath);
    res.writeHead(200, { 'Content-Type': MIME[ext] || 'application/octet-stream' });
    res.end(content);
  });
}

const server = http.createServer(async (req, res) => {
  let urlObj;
  try { urlObj = new URL(req.url, `http://${req.headers.host || 'localhost'}`); }
  catch (e) { res.writeHead(400); res.end('Bad Request'); return; }
  const pathname = urlObj.pathname;

  try {
    if (pathname === '/api/health' && req.method === 'GET') {
      return sendJson(res, 200, { ok: true, time: new Date().toISOString() });
    }

    // ---------- تسجيل الدخول / الخروج (بدون حماية) ----------
    if (pathname === '/api/login' && req.method === 'POST') {
      const body = await readBody(req);
      if (!body || !verifyPassword(String(body.password || ''))) {
        return sendJson(res, 401, { error: 'كلمة المرور غير صحيحة' });
      }
      const token = createSession();
      res.setHeader('Set-Cookie', `session=${token}; HttpOnly; Path=/; Max-Age=${SESSION_TTL_MS / 1000}; SameSite=Lax`);
      return sendJson(res, 200, { ok: true });
    }
    if (pathname === '/api/logout' && req.method === 'POST') {
      const token = getCookie(req, 'session');
      if (token) SESSIONS.delete(token);
      res.setHeader('Set-Cookie', 'session=; HttpOnly; Path=/; Max-Age=0');
      return sendJson(res, 200, { ok: true });
    }
    if (pathname === '/api/change-password' && req.method === 'POST') {
      if (!isValidSession(getCookie(req, 'session'))) return sendJson(res, 401, { error: 'غير مسموح' });
      const body = await readBody(req);
      if (!body || !verifyPassword(String(body.oldPassword || ''))) {
        return sendJson(res, 401, { error: 'كلمة المرور الحالية غير صحيحة' });
      }
      if (!body.newPassword || String(body.newPassword).length < 4) {
        return sendJson(res, 400, { error: 'كلمة المرور الجديدة قصيرة جدًا (4 أحرف على الأقل)' });
      }
      const salt = crypto.randomBytes(16).toString('hex');
      writeConfig({ salt, hash: hashPassword(String(body.newPassword), salt) });
      return sendJson(res, 200, { ok: true });
    }

    // ---------- بوابة العميل العامة (قراءة فقط، بدون تسجيل دخول) ----------
    if (pathname.startsWith('/api/portal/') && req.method === 'GET') {
      const clientId = pathname.split('/')[3];
      const db = readDb();
      const c = (db.clients || []).find(cl => cl.id === clientId);
      if (!c) return sendJson(res, 404, { error: 'العرض غير موجود' });
      // مهم: لا نرسل أبدًا سعر التكلفة (unitPrice) ولا نسبة هامش الربح للعميل —
      // فقط السعر النهائي بعد احتساب الهامش، لحماية بيانات التسعير الداخلية
      const margin = parseFloat(c.marginPercent) || 0;
      const items = (c.items || []).map(it => {
        const qty = parseFloat(it.qty) || 0;
        const cost = qty * (parseFloat(it.unitPrice) || 0);
        const sell = Math.round(cost * (1 + margin / 100) * 100) / 100;
        return { catalogId: it.catalogId || '', customName: it.customName || '', location: it.location || '', qty, sell };
      });
      const installation = parseFloat(c.installationFee) || 0;
      const itemsTotal = items.reduce((s, it) => s + it.sell, 0);
      const grandTotal = Math.round((itemsTotal + installation) * 100) / 100;
      const collected = (c.payments || []).reduce((s, p) => s + (parseFloat(p.amount) || 0), 0);
      return sendJson(res, 200, {
        name: c.name, status: c.status, items, installation, grandTotal,
        quoteDate: c.quoteDate, quoteValidDays: c.quoteValidDays,
        collected, remaining: Math.round((grandTotal - collected) * 100) / 100,
        tasks: c.tasks || []
      });
    }

    // ---------- كل ما بعد هذا يحتاج تسجيل دخول ----------
    const protectedRoutes = ['/api/state', '/api/backup'];
    if (protectedRoutes.includes(pathname) && !isValidSession(getCookie(req, 'session'))) {
      return sendJson(res, 401, { error: 'الرجاء تسجيل الدخول' });
    }

    if (pathname === '/api/state' && req.method === 'GET') {
      return sendJson(res, 200, readDb());
    }
    if (pathname === '/api/state' && req.method === 'POST') {
      const body = await readBody(req);
      if (!body || typeof body !== 'object' || Array.isArray(body)) {
        return sendJson(res, 400, { error: 'بيانات غير صالحة' });
      }
      await writeDb(body);
      return sendJson(res, 200, { ok: true });
    }
    if (pathname === '/api/backup' && req.method === 'GET') {
      const data = readDb();
      const body = JSON.stringify(data, null, 2);
      const stamp = new Date().toISOString().slice(0, 10);
      res.writeHead(200, {
        'Content-Type': 'application/json; charset=utf-8',
        'Content-Disposition': `attachment; filename="alwan-alhayat-backup-${stamp}.json"`,
        'Content-Length': Buffer.byteLength(body)
      });
      return res.end(body);
    }
    if (pathname.startsWith('/api/')) {
      return sendJson(res, 404, { error: 'مسار غير موجود' });
    }
    if (req.method !== 'GET') { res.writeHead(405); res.end('Method Not Allowed'); return; }
    return serveStatic(req, res, pathname);
  } catch (e) {
    return sendJson(res, 500, { error: 'خطأ في الخادم: ' + e.message });
  }
});

server.listen(PORT, () => {
  console.log('====================================================');
  console.log(' ألوان الحياة للديكور — النظام يعمل الآن');
  console.log(' افتح المتصفح على: http://localhost:' + PORT);
  console.log(' قاعدة البيانات: ' + DB_FILE);
  console.log('====================================================');
});
