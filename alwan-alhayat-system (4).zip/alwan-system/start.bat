@echo off
cd /d "%~dp0"
echo جارٍ تشغيل نظام ألوان الحياة للديكور...
node server.js
pause
