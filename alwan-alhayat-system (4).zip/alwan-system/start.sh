#!/bin/bash
cd "$(dirname "$0")"
echo "جارٍ تشغيل نظام ألوان الحياة للديكور..."
node server.js
